
#ifndef SIGNAL_H__
#define SIGNAL_H__


extern float LeSignal[64];


#endif


