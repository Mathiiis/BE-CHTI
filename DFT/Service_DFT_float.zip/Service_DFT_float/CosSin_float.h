
#ifndef TAB_FLOAT_H__
#define TAB_FLOAT_H__

extern float TabCos[64];
extern float TabSin[64];

#endif


